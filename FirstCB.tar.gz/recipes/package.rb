package 'apache2' do
 action :install
end
